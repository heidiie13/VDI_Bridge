# EXAMPLES — Ví dụ cấu hình AgentWork

Các ví dụ 1–3 minh họa skill config. Chúng không phải Workflow runtime durable. Tool names là ví dụ; khi triển khai cần map DB tool type/schema thật.

## 1. Flat agent — tư vấn sản phẩm

```markdown
## Agent
Tên: Trợ lý tư vấn sản phẩm
Mô tả: Tư vấn sản phẩm theo nhu cầu và quy mô khách hàng.

## Instruction ngoài
Bạn là tư vấn viên sản phẩm.
Được làm: hỏi nhu cầu, tra cứu tính năng, giải thích lựa chọn.
Không làm: đoán giá/SKU, tư vấn đối thủ như sự thật.
Khi thiếu dữ liệu: nói rõ và gọi tool phù hợp.

## Answer Style
Thân thiện, ngắn, bullet khi cần.

## Skill — Tư vấn
Mô tả: Tra cứu tính năng, so sánh gói theo ngành nghề và quy mô.
Tools:
- get_product_features — dùng khi hỏi tính năng/gói.
- search_product — dùng để lấy SKU/evidence hiện tại.
```

Không ghi chuyển sang skill khác nếu agent chỉ có một effective skill; flat graph không có Router/skill đích.

## 2. Multi-skill — bán hàng và hỗ trợ

```markdown
Skill — Bán hàng
Mô tả: Khám phá nhu cầu, so sánh gói, tra giá, báo giá, xử lý mua hàng.
Instruction: Khi khách xác nhận mua, chuyển sang "Onboarding" nếu skill đó tồn tại.

Skill — Hỗ trợ
Mô tả: Cài đặt, lỗi đăng nhập, hướng dẫn tính năng, ticket kỹ thuật.
Instruction: Không báo giá; hỏi phiên bản và mã lỗi trước.
```

`create_order` cần HITL nếu nghiệp vụ yêu cầu:

```text
HITL: có — approve/edit/reject trước khi tạo đơn.
```

Test gồm route bán hàng, route kỹ thuật, overlap, chuyển tiếp, out-of-scope. Không gọi tất cả là Router nếu runtime thực tế flat.

## 3. Knowledge/channel checks

Knowledge upload có thể auto-inject search tool hoặc knowledge skill tùy effective structure; không tự tạo skill “Knowledge” trong output trừ khi user yêu cầu.

Kênh Facebook/Zalo/ZaloOA/TikTokBusiness cần kiểm tra `chat_tool`; web không suy ra behavior force-tool.

## 4. Workflow runtime — sales order

```yaml
nodes:
  - id: choose_product
    type: agent
    objective: Xác định sản phẩm và biến thể khách muốn mua
    agent_source:
      inline:
        allowed_tools: [search_product, search_combo]
        collect:
          - name: product_sku
            scope: run
            data_type: string
            source: ai_extract
            validator: exact_catalog_sku
          - name: quantity
            scope: run
            data_type: integer
            source: ai_extract
            validator: positive
        recompute_on: []
  - id: confirm_order
    type: agent
    objective: Xác nhận thông tin và tạo đơn sau phê duyệt
    agent_source:
      inline:
        allowed_tools:
          - get_customer_info
          - create_order
        collect:
          - name: shipping_address
            scope: customer
            data_type: string
            source: ai_extract
            validator: non_empty
  - id: done
    type: end
edges:
  - from: choose_product
    to: confirm_order
    when: product_sku != null and quantity != null
    priority: 1
  - from: confirm_order
    to: done
    when: order_created == true
    priority: 1
```

Rules:
- One root, explicit end, no cycle; node list order irrelevant.
- Edge null is default and last. `when` controls branch/completion.
- `allowed_tools: []` means no tools; omitted/None follows contract default. Do not use `or None` normalization.
- Engine injects `record_step_result`; optional `call_agent` is node partner capability. Do not list either as ordinary LLM tools. Do not use `agent_ref` in new authoring.
- State is StateStore/checkpoint, not instruction. Runtime status/scope/write policy must be explicit.
- Resume same instance. `advance() is None` means remain; only explicit end completes. `revise_field` targets variable keys and cascades invalidation; amend confirmation uses `<var>_amend_confirmed`.
- Product/price/combo claims require current-turn `search_product`/`search_combo` evidence, exact SKU/combo and provenance. No manual total arithmetic.

## 5. Behavior tests

1. Sales question routes to sales, technical question to support.
2. Flat agent does not claim Router transition without target skill.
3. Product answer rejects ambiguous/stale SKU and calls catalog search.
4. Workflow resumes existing instance, not new instance.
5. Workflow with no matching edge remains active, not completed.
6. Rejected HITL does not execute create/update tool.
7. Catalog reply preserves current-turn provenance.
8. Forced channel calls `chat_tool`.
9. Voice path remains async STT → graph → TTS.
10. A2A `input-required` resumes through checkpoint.
