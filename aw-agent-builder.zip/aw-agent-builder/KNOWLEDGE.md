# KNOWLEDGE — AgentWork Platform hiện hành

Nguồn ưu tiên: source `src/`, `src/workflow/AGENTS.md`, authoring contract GD3/GD4. `docs/workflow-engine-architecture.md` là tài liệu lịch sử, không dùng làm contract nếu mâu thuẫn.

## 1. Hai runtime khác nhau

### Skill orchestration
Agent config gồm instruction ngoài, một answer style, skills và tools. Graph factory tại `src/db/services/agent_manager.py::AgentManager.get_agent_graph`:

| orchestration | graph | Ý nghĩa |
|---|---|---|
| `MISA_ATLAS` (1) | `atlas_graph` | Router/skill dispatch |
| `AISELL` (2) | `fc_graph` | Flat ReAct |
| `AISELL_NEW` (3) | `dynamic_graph` | Skill + supervisor, transition |
| `DEEPAGENTS` (4) | per-request DeepAgent | Sandbox, subagents |
| `DYNAMIC` (5) | `dynamic_graph` | SLM pre-route rồi supervisor |
| `AGENTWORKSALE` (6) | `agentworksale_graph` | Vertical sales nội bộ; không dùng để chọn mode cho agent mới |

`agent_config.use_fc_graph` bypass router. Voice dùng `voice_atlas_graph`. BA không tự chọn mode; mô tả domain, skill, tool, HITL, workflow và A2A để AI team map.

### Workflow runtime
Workflow không phải orchestration mode hay chuỗi skill. Đây là graph/state runtime được gắn vào sales path, với `agent`/`end` nodes, edges và StateStore/checkpoint. Một workflow domain thường là một skill, nhưng skill không thay thế workflow engine.

## 2. Skill model

Skill types: `NO_CODE`, `A2A_EXTERNAL`, `A2A_INTERNAL`, `SUPPORT`, `CONNECTOR`, `KNOWLEDGE`, `UI_FORM`. KNOWLEDGE thường platform tự sinh từ knowledge/FAQ. UI_FORM virtual skill chỉ khi bật UI interaction. Workflow node không được dùng UI_FORM; validator từ chối.

Router chỉ đọc tên + mô tả skill. Instruction bên trong không giúp Router phân loại. Mô tả phải độc quyền scope.

Auto-inject phụ thuộc mode/config:
- ≤1 effective skill thường tự dùng `fc_graph`.
- Knowledge: flat agent nhận search tool; multi-skill nhận RAG skill.
- Một số mode thêm `general_purpose` fallback.
- FAQ bật có thể inject `get_faq`.
- AISELL_NEW/AGENTWORKSALE có transition schema theo skill; workflow path có thể strip transition.

## 3. Tool model

Tool types: `BUILT_IN`, `HTTP`, `HTTP_AMIS`, `MISA_FUNC`, `STRUCTURED_RESPONSE`, `MCP`, `CONNECTOR`, `UI_FORM`.

BUILT_IN:
- STATIC: DB `input_params=[]`, schema từ Pydantic.
- DYNAMIC: DB params merge vào schema; field có thể bị disable phải khai `Optional[...] = None`; schema cho phép extra. Registry giữ HITL và sensitive-data metadata.

Built-in thường gặp: knowledge/FAQ/search, calculator, google/url context, handoff, chat/structured message, memory, connector discovery. `command_caller`, `http_caller`, `ui_form_caller` là internal caller, không expose LLM.

Kênh Facebook, Zalo, ZaloOA, TikTokBusiness force `chat_tool`; thiếu tool delivery có thể làm tin không gửi.

## 4. Workflow authoring contract

Authoring hiện hành dùng `agent_source`, không dùng schema cũ `agent_ref` làm contract mới. Backward compatibility có thể normalize các key cũ (`instruction`, `skill_code`, `extract_variables`, `depends_on`), nhưng output mới dùng:

- `objective`: bắt buộc, 1–300 ký tự.
- `agent_source`: inline hoặc `call_agent` partner.
- Inline cần `allowed_tools`; `[]` nghĩa không có tool, khác với omitted/`None` là không cắt tool theo contract.
- `allowed_tools` nhận list tên hoặc list dict raw tool.
- `collect`: biến cần thu thập; `recompute_on`: dependency explicit; omitted có thể suy closure, `[]` nghĩa không dependency.
- Runtime node types có `agent`, `end`, `system`; authoring web chủ yếu nhận `agent`/`end`.
- Graph phải có đúng một root, explicit end, không cycle. `nodes` chỉ là danh sách khai báo, không quyết định execution.
- Edges mới quyết định execution. `when` là completion/branch condition; edge null là default và phải đứng cuối theo priority. Compiler map node UUID authoring sang node code runtime.
- Engine validates self-call, shadow-tool exposure, illegal engine tool names, và `call_agent`/`tool_output` incompatibility.

Workflow state nằm StateStore/Mongo, keyed bởi tenant + thread + instance. Scope authoring thường `run`/`customer`; runtime có `INSTANCE`/`CUSTOMER`. Status gồm `UNSET`, `FRESH`, `INVALIDATED`; write policy gồm `SYSTEM_ONLY`, `VALIDATED`, `AGENT`. Instance có RUNNING/COMPLETED/ESCALATED/EXPIRED. Không giả định mọi nghiệp vụ có DRAFT/FINALIZED.

Runtime loop `on_message` xử lý current node, checkpoint, retry/wait/advance/escalate. `turn_settled_<node_id>` là gate runtime hiện tại; chưa settled hoặc không có edge match thì ở lại node, không coi completed. Chỉ explicit `end` mới hoàn tất. `matched_step`/`revise_field` có thể reopen cục bộ và cascade invalidate biến phụ thuộc; không rollback toàn graph.

Engine injects `record_step_result` và có thể inject `call_agent`; đây là shadow/internal engine contract, không đưa vào danh sách tools LLM. `call_agent` là partner declaration ở node, không phải tool thường. Không đưa `chat`, `send_message`, `send_structured_message` vào workflow `allowed_tools` theo contract.

## 5. HITL, A2A, memory, voice

Tool HITL: `hitl.enabled`, optional `when`, allowed decisions `approve/edit/reject/change_intent`; interrupt trước execute, resume qua checkpoint. Đây khác workflow wait/retry/checkpoint. Tool GET/search/memory read thường không HITL. Side effect phải idempotent vì resume có thể chạy lại node.

A2A_EXTERNAL/SUPPORT dùng A2A graph; A2A_INTERNAL resolve full production agent rồi invoke graph. `input-required`/`auth-required` là interrupt states. A2A async-first.

Checkpoint short-term giữ messages/thread/checkpoint/pending writes. Transfer state tách `transfer_flow` và `transfer_memory`; long-term memory dùng `get/search/write/edit_memory`. `MemoryFlushNode` chạy cuối graph. Workflow variables ở StateStore, không nhét vào instruction/config.

Voice: LiveKit token → streaming MISA STT (16k PCM/VAD) → LangGraph adapter → streaming MISA TTS. Graph invocation async.

## 6. Request/stream lifecycle

`RunService.create_run` tạo UUID, khóa multitask qua RunCache/Redis. `stream_run` validate multimodal input, resolve config/graph, stream `messages`, `updates`, `custom`; có quick replies, structured tool output, root `__interrupt__`, cancellation và completion. Safety gate có thể hủy pump rồi rerun refusal/handoff. `cancel_run` ghi checkpoint/cancellation state và stream `run_cancelled`.

## 7. Config-first remediation matrix

| Symptom | Thử trước từ phía dự án | Không đủ khi nào | Escalation kỹ thuật |
|---|---|---|---|
| Trả lời sai/thiếu | Sửa instruction, answer style, skill scope, knowledge prompt | Prompt rõ nhưng model vẫn vi phạm với input tái hiện | Model/runtime issue với log |
| Gọi sai skill | Sửa skill description, negative boundary, enabled/order, transition instruction | Router vẫn route sai sau test matrix | Router/schema bug |
| Không gọi tool | Sửa tool description, trigger, params, skill mapping, built-in pool | Tool không xuất hiện trong initialized schema | Initializer/registry bug |
| Gọi tool sai args | Sửa param description/example, schema mode, Optional/extra config | Payload runtime khác schema hoặc handler sai | Tool handler/API bug |
| Tự ý write | Bật HITL, `when`, allowed decisions, prompt approval | Interrupt không xuất hiện hoặc execute trước approval | HITL/runtime bug |
| Knowledge sai | Re-index, sửa tài liệu, metadata filter, search instruction | Tool trả evidence sai/empty dù index đúng | RAG/index service bug |
| Workflow đứng/sai nhánh | Sửa objective, collect, edge condition/priority, validator, revise rule | State/checkpoint/edge runtime sai dù config hợp lệ | Workflow engine bug |
| Kênh không gửi | Kiểm tra channel, `chat_tool`, optimize config | Force call có nhưng delivery fail | Channel/message service bug |
| A2A/voice lỗi | Kiểm tra selected agent, endpoint/config, async settings, prompt handoff | Protocol/session lỗi dù config đúng | A2A/STT/TTS runtime bug |

## 8. Sales evidence

Các claim sản phẩm/giá/combo phải dựa trên current-turn result của `search_product`/`search_combo`, exact SKU/variant/combo và source provenance. Không tự đoán SKU, dùng evidence cũ/mơ hồ, hoặc tự cộng total thay API. Reconfirm customer-scoped shipping/ordering variables khi bị invalidated.
