# PATTERNS — Thiết kế AgentWork hiện hành

## Nguyên tắc chọn lớp sửa

Mọi pattern phải triển khai được bởi đội tích hợp trước:

1. Prompt: instruction ngoài, answer style, skill instruction.
2. Metadata: skill description, tool description/params, HITL, schema, enabled/mapping.
3. Workflow/knowledge config: objective, collect, edges, validators, documents, metadata filters.
4. Integration data: API payload, connector/A2A endpoint, channel settings.
5. Internal engineering: chỉ sau khi bốn lớp trên không giải quyết được và có reproduction.

Khi báo lỗi, đưa bản sửa copy-paste trước; không yêu cầu sửa source code nếu chưa chứng minh config không đủ.

## Pattern 1 — Agent đơn giản / flat

Dùng cho một domain, ít skill hiệu lực, không cần Router. Đây là heuristic, không phải ngưỡng platform. Platform quyết định `use_fc_graph` theo effective skill count và auto-injection.

```text
Instruction ngoài: vai trò, nhiệm vụ, giới hạn, fallback
Answer Style: một block ở agent level
Skill: mô tả scope + instruction + tools
```

Không đặt transition sang skill khác trong agent một skill; nếu cần chuyển, phải có skill đích hiệu lực.

## Pattern 2 — Multi-skill theo domain

Tách theo domain, không theo bước. Router chỉ đọc tên/mô tả skill.

```text
Skill bán hàng: tư vấn sản phẩm, giá, báo giá, đặt hàng
Skill hỗ trợ: cài đặt, lỗi, ticket
```

Mỗi mô tả cần positive scope và negative boundary. Dùng 5 câu test/domain; thêm câu overlap để tìm route không ổn định. Số tool/độ dài instruction chỉ là heuristic.

## Pattern 3 — Chuyển skill

AISELL_NEW/AGENTWORKSALE có thể được inject transition schema; AISELL_NEW giới hạn tối đa một transition mỗi turn. MISA_ATLAS/DYNAMIC có graph routing khác; không giả định mọi mode dùng cùng tool.

Trong instruction:

```text
Khi khách đã [điều kiện rõ], chuyển sang skill "[tên/code chính xác]".
Trước khi chuyển, nói: "..."
```

Không tự liệt kê `transition_skill`; không dùng transition cho workflow node nếu AgentRunner đã strip cơ chế này.

## Pattern 4 — Tool HTTP/BUILT_IN

```markdown
### get_product_price
- Mô tả: Tra cứu giá hiện tại theo SKU. Dùng khi khách hỏi giá hoặc so sánh gói.
- Tham số:
  - product_code: SKU chính xác. Ví dụ: MISA-SME-ENT.
  - quantity: Số license. Ví dụ: 3.
- HITL: không.
```

Tên dùng `verb_noun`. Ghi precondition, output/error và ví dụ. Với BUILT_IN, phân biệt STATIC (`input_params=[]`) và DYNAMIC (schema merge từ DB; field có thể bị disable phải Optional/None, extra allow).

## Pattern 5 — Tool HITL

Dùng cho create/update/delete, đổi rule, action hậu quả lớn. Không bật cho GET/search/memory read nếu không có yêu cầu đặc biệt.

```json
{"hitl":{"enabled":true,"allowed_decisions":["approve","edit","reject","change_intent"],"when":null}}
```

`when` hỗ trợ condition đơn, `all`, `any`; ví dụ `total > 10000000`. Nói rõ agent đề xuất, không tự áp dụng; im lặng không phải approve. Tool HITL interrupt trước execute, khác workflow wait/retry/checkpoint. Thiết kế side effect idempotent vì resume có thể chạy lại node. UI_FORM và A2A có interrupt protocol riêng.

## Pattern 6A — Conversational workflow trong một skill

Dùng khi chỉ cần instruction dẫn dắt vài bước, không cần durable instance, branch engine, resume sau gián đoạn hoặc cascade state. Ghi thứ tự và điều kiện trong instruction; không gọi đây là Workflow runtime.

## Pattern 6B — Platform Workflow runtime

Dùng khi có graph/state/resume/branch/back-jump/retry/wait/escalate. Một domain workflow thường là một skill; engine quyết định bước, không Router.

### Authoring template

```yaml
nodes:
  - id: collect_customer
    type: agent
    objective: Thu thập thông tin khách hàng cần cho đơn hàng
    agent_source:
      inline:
        allowed_tools: [search_product]
        collect:
          - name: customer_name
            scope: customer
            data_type: string
            source: ai_extract
            validator: non_empty
    # omitted allowed_tools != []: khác với explicit no tools
  - id: finish
    type: end
edges:
  - from: collect_customer
    to: finish
    when: customer_name != null
    priority: 1
```

Contract: đúng một root, explicit `end`, không cycle; node list chỉ khai báo, edges quyết định execution; edge null là default đặt cuối; compiler map UUID sang node code. `objective` 1–300 ký tự. `allowed_tools=[]` nghĩa không tool; `None`/omitted nghĩa không cắt tool theo contract. `collect` thay `extract_variables`; `recompute_on` thay `depends_on`; legacy keys chỉ để compatibility.

State do engine giữ trong StateStore/checkpoint, scope runtime INSTANCE/CUSTOMER, status UNSET/FRESH/INVALIDATED, write policy SYSTEM_ONLY/VALIDATED/AGENT. Không nhét workflow state vào instruction/config và không giả định mọi workflow có DRAFT/FINALIZED.

Engine inject `record_step_result`; có thể inject `call_agent` theo `agent_source`. Đây là shadow/internal contract, không đưa vào LLM-facing allowed tools. Không expose UI_FORM node, `chat`, `send_message`, `send_structured_message`, hay `agent_ref` cũ.

Completion phụ thuộc edge condition và explicit end. `advance() is None` nghĩa còn ở node, không phải completed. `revise_field` nhận variable key, cascade invalidate biến phụ thuộc; amend confirmation dùng `<var>_amend_confirmed`. Không mô tả `user_wants_revise_*` hay `turn_settled_*` như public authoring contract.

## Pattern 7 — A2A / connector / UI

Chỉ đề xuất khi cần agent hoặc hệ thống chuyên biệt. A2A_EXTERNAL/SUPPORT cần AI team; A2A_INTERNAL resolve agent production. A2A async-first, có `input-required`/`auth-required`. UI_FORM tạo payload frontend và interrupt; không đặt UI_FORM vào workflow node.

## Pattern 8 — Evidence-backed catalog

`search_product`/`search_combo` trước khi trả claim giá/SKU/combo. Chỉ dùng exact variant và current-turn provenance. Không tự cộng tổng, dùng evidence cũ/mơ hồ, hoặc đoán SKU. Giữ citation evidence đến reply/structured response.

## Pattern 9 — Voice/channel

Kênh Facebook/Zalo/ZaloOA/TikTokBusiness cần `chat_tool`. Voice pipeline: LiveKit → MISA streaming STT → graph adapter → MISA streaming TTS; tất cả async. Test riêng channel/voice, không suy behavior web từ voice.
