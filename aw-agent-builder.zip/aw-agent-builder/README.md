# aw-agent-builder

Skill cho Claude Code giúp thiết kế, debug và review cấu hình agent trên **AgentWork Platform**.

---

## Skill này làm được gì

| Tình huống | Dùng lệnh |
|------------|-----------|
| Thiết kế agent mới từ mô tả nghiệp vụ | `/aw-agent-builder` |
| Debug agent trả lời sai, gọi nhầm tool | `/aw-agent-builder debug: ...` |
| Review cấu hình agent hiện tại | `/aw-agent-builder review: ...` |

---

## Cài đặt

### Yêu cầu
- [Claude Code](https://claude.ai/code) đã được cài đặt
- Claude Code CLI đang chạy trong terminal

### Bước 1 — Copy folder vào thư mục skills

```bash
# Tạo thư mục skills nếu chưa có
mkdir -p ~/.claude/skills

# Copy toàn bộ folder này vào
cp -r aw-agent-builder ~/.claude/skills/
```

### Bước 2 — Khởi động lại Claude Code

Thoát và mở lại Claude Code để skill được load.

### Bước 3 — Kiểm tra

Trong Claude Code, gõ:
```
/aw-agent-builder
```

Nếu skill hoạt động, Claude sẽ hỏi bạn muốn thiết kế agent gì.

---

## Cách dùng

### Thiết kế agent mới

```
/aw-agent-builder
```

Skill sẽ hỏi tuần tự để hiểu nghiệp vụ, đề xuất 2 phương án tổ chức skill, rồi sinh cấu hình hoàn chỉnh sau khi bạn chọn.

**Output bạn nhận được:**
- `Instruction (ngoài)` — paste vào field Instruction của agent
- `Answer Style` — paste vào field Answer Style
- Từng `Skill` với mô tả, instruction riêng và danh sách tool (tên, mô tả, tham số)
- 5 câu hỏi test để kiểm tra Router phân công đúng không

---

### Debug agent hành xử sai

```
/aw-agent-builder debug: Input: [...] Output: [...] Kỳ vọng: [...]
```

Cần cung cấp đủ 3 thứ:

```
Input LLM:   [system prompt + lịch sử chat + danh sách tool]
Output LLM:  [agent đã nói gì, gọi tool gì, tham số gì]
Kỳ vọng:     [hành vi đúng mong muốn]
```

Skill sẽ chỉ ra đúng phần cần sửa (instruction / mô tả tool / mô tả skill) kèm nội dung sửa cụ thể.

**Ví dụ:**
```
/aw-agent-builder debug: Input: [system prompt...] Output: agent gọi get_candidates 2 lần rồi báo không tìm thấy CV Kỳ vọng: agent phải dùng CandidateID từ kết quả get_schedule để gọi get_candidate_cv
```

---

### Review cấu hình hiện tại

```
/aw-agent-builder review: [paste cấu hình agent vào đây]
```

Skill kiểm tra 4 điểm:
1. Instruction ngoài — đủ 4 câu hỏi cốt lõi? mâu thuẫn?
2. Mô tả skill — cụ thể? có scope trùng nhau không?
3. Tools — tên rõ? mô tả đủ? tham số có ví dụ?
4. Answer Style — có không? mâu thuẫn instruction?

Output là danh sách cải thiện ưu tiên theo mức độ ảnh hưởng.

---

## Cấu trúc file

```
aw-agent-builder/
├── SKILL.md          # Logic chính của skill
├── KNOWLEDGE.md      # Kiến trúc orchestration + Workflow runtime hiện hành
├── PATTERNS.md       # Pattern skill, tool, HITL, workflow, A2A, evidence
├── ANTIPATTERNS.md   # Lỗi cấu hình, workflow, runtime và provenance
├── EXAMPLES.md       # Ví dụ flat, multi-skill, knowledge/channel, workflow runtime
└── README.md         # File này
```

---

## Kiến trúc AgentWork Platform (tóm tắt)

Hiểu điều này giúp bạn dùng skill hiệu quả hơn. Đây không phải quy tắc chọn graph tuyệt đối:

| Effective skill | Hành vi thường gặp | Lưu ý |
|----------|-------------|-------------|
| ≤1 | `fc_graph` phẳng | Có thể thay đổi bởi knowledge auto-skill, UI, A2A/SUPPORT và orchestration |
| >1 | Router/supervisor | Graph cụ thể phụ thuộc agent config/orchestration |
| Workflow runtime | Engine graph/state riêng | Không phải chuỗi skill; cần workflow authoring config |

**Điểm quan trọng nhất:** Router chỉ đọc **tên + mô tả skill** để phán đoán. Mô tả mơ hồ → Router phân công sai → agent trả lời sai.

**Quy tắc hỗ trợ dự án tích hợp:** Khi review/debug, ưu tiên sửa instruction, skill description, tool metadata/schema, HITL, workflow authoring, knowledge và integration config. Chỉ chuyển đội kỹ thuật sau khi có reproduction và đã loại trừ các lớp config.

---

## Ví dụ output mẫu

Xem file `EXAMPLES.md` để tham khảo các cấu hình mẫu:
- Flat agent và multi-skill theo domain
- Knowledge/channel checks
- Workflow runtime có state, edge, resume, revise
- Evidence-backed catalog

---

## Troubleshooting

**Skill không được nhận ra sau khi cài:**
- Kiểm tra đúng đường dẫn: `~/.claude/skills/aw-agent-builder/SKILL.md`
- Khởi động lại Claude Code hoàn toàn (không chỉ reload)

**Skill load nhưng không hỏi gì, trả lời ngay:**
- Bình thường với yêu cầu debug/review — skill chỉ hỏi tuần tự khi thiết kế agent mới
- Nếu thiết kế mới mà không hỏi: thêm chữ "thiết kế" vào prompt

**Output thiếu mô tả tool hoặc tham số:**
- Cung cấp thêm thông tin về API/hệ thống cần tích hợp khi skill hỏi "Nguồn dữ liệu"
