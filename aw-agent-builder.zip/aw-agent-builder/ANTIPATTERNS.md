# ANTIPATTERNS — Lỗi thiết kế agent

## A. Instruction

- Không có vai trò/nhiệm vụ/giới hạn/fallback.
- Mâu thuẫn ngôn ngữ, giá, điều kiện.
- Quá dài hoặc pseudo-code khó đọc. Mốc `<500 từ` chỉ là heuristic, không phải giới hạn runtime.
- Viết cho developer thay vì LLM.

## B. Tool

- Tên mơ hồ, thiếu trigger/precondition/params/output/error.
- Gộp quá nhiều tool không liên quan; ngưỡng 5–6 chỉ là heuristic.
- Bật HITL cho GET/search/memory read không cần thiết.
- BUILT_IN dynamic schema không `Optional=None`/`extra=allow`.
- Dùng sai built-in pool giữa FC và Atlas/AgentWorkSale.
- Kênh Facebook/Zalo/ZaloOA/TikTokBusiness không có force `chat_tool`.
- Liệt kê `transition_skill`, `record_step_result`, `call_agent`, `command_caller`, `http_caller` như LLM-facing tool.

## C. Skill/router

- Mô tả skill chung chung hoặc overlap; Router chỉ đọc description.
- Tạo catch-all trùng với `general_purpose` auto-inject; predicate phụ thuộc orchestration, không mặc định mọi mode.
- Nghĩ mọi chain dùng cùng transition mechanism.
- Gắn transition vào agent chỉ có một effective skill; không có skill đích.
- Gọi `transition_skill` trong workflow path nơi AgentRunner strip nó.

## D. Knowledge/catalog

- Coi “không tìm thấy” luôn là bug index; phân biệt index, retrieval, knowledge miss và moderation.
- Để LLM đoán khi tài liệu/catalog thiếu.
- Claim SKU/giá/combo từ evidence cũ, mơ hồ hoặc khác turn.
- Tự cộng giá thay tool/API; bỏ source provenance trước reply.

## E. HITL

- Write action chạy trước interrupt.
- Coi “ờ/ừ” là approve; bỏ qua `edit/reject/change_intent`.
- Dùng HITL cho mọi GET.
- Nhầm tool HITL với workflow wait/checkpoint. Hai cơ chế khác nhau; side effect phải idempotent khi resume.
- Expose raw interrupt/diagnostic/escalation reason cho khách; chỉ gửi customer-safe fallback, giữ reason nội bộ.

## F. Workflow runtime

- Coi workflow nhiều bước là chuỗi skill; tách skill theo step thay vì domain.
- Lưu durable state trong instruction/config hoặc tự tạo GET state tool khi engine đã giữ StateStore/checkpoint.
- Dùng schema cũ `agent_ref` làm contract mới.
- Thiếu `objective`, `allowed_tools`, `collect`, `recompute_on`; nhầm `[]` với omitted.
- Đưa UI_FORM vào workflow node.
- Dùng `allowed_tools` lẫn shape không hợp lệ; expose engine shadow tools.
- Thiếu root/end, cycle, edge dangling, default edge không đặt cuối, hoặc dùng thứ tự nodes để suy execution.
- Nhầm UUID authoring với node code runtime.
- Coi `advance() is None` là completed; completion chỉ qua explicit end/edge semantics.
- Giả định mọi workflow có DRAFT/FINALIZED; không khai scope/status/write policy.
- Revise theo node ID thay vì `revise_field` theo variable key; không cascade invalidation.
- Document `user_wants_revise_*` hoặc `turn_settled_*` như public authoring input; current contract không expose chúng như field người dùng cấu hình.
- Tạo instance mới thay vì resume đúng tenant/thread/instance.
- Dùng `recompute_on` omitted khi cần explicit no dependency; phải dùng `[]`.

## I. Config-first remediation

- Đề xuất code fix ngay khi prompt chưa được kiểm tra.
- Gửi đối tác tích hợp vào source path, graph internals hoặc test code dù họ chỉ có quyền sửa config.
- Nói “platform bug” khi chưa có input/output/config diff và reproduction.
- Sửa nhiều lớp cùng lúc khiến không biết thay đổi nào có tác dụng.
- Không cung cấp text prompt/schema/config có thể copy-paste.
- Không có acceptance criteria quan sát được: expected tool, expected skill, expected HITL, expected event, expected state.
- Đề xuất escalation mà không ghi rõ workaround config đã thử và vì sao thất bại.

## G. Runtime/debug

- Debug chỉ prompt mà không kiểm tra initialization, channel, graph mode, checkpoint/thread, stream events, cancellation.
- Đọc `sub_agent` stale thay vì router dispatch AIMessage trong workflow bridge.
- Gọi sync A2A/STT/TTS trong event loop.
- Cho graph error/retry exhaustion lộ node ID/reason ra khách.
- Không test OpenAI `{function:{name}}` và Google `{name}` tool schemas, HumanMessage boundary, active workflow filter, terminal fallback.
- Không test safety rerun, `run_cancelled`, root-only interrupt, quick reply/structured output.

## H. Source of truth

Không dùng `docs/workflow-engine-architecture.md` làm contract hiện tại; tài liệu đó stale và còn schema `agent_ref`. Ưu tiên source/AGENTS/authoring contract; khi conflict, ghi rõ version và kiểm chứng code.
